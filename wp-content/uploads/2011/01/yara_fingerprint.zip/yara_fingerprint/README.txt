Author: 0xdabbad00, 2011.01.09

These rules are based on HBGary's FingerPrint tool: 
- https://www.hbgary.com/community/free-tools/#fingerprint
These rules are for YARA
- http://code.google.com/p/yara-project/

Run as:
yara.exe -g -m fingerprints.yar file_to_scan.exe

See my post at:
- http://0xdabbad00.com/2011/01/09/fingerprinting-using-yara/
