﻿Test executables
================
Two executables are compiled: minimal and recursive.  I wanted to make code that was as simple as possible, so it just returns values as opposed to using printf.

Minimal
-------
Run minimal.exe and then "echo %ERRORLEVEL%" and your command shell prints 42

    int main(int argc, char** argv) {
        return 42;
    }


Recursive
---------
Uses the number of arguments to return the factorial of that count.  Ex. "recursive.exe a a a" returns 4*3*2*1 = 24

    int factorial(int a) {
        if (a == 1) return a;
        return a * factorial(a - 1);
    }

    int main(int argc, char** argv) {
        return factorial(argc);
    }




Windows XP SP3
==============

Visual Studio 6
---------------
Source: Old install CD's I bought back in 1998.  Had to remove uuid.lib references because my file was corrupted it seems (CD's from 1998 have are dying).
Process: Created new empty console projects.  Also compiled via command-line by simply running "cl minimal.cpp"
Files: *_VS6*.exe; D = Debug; R = Release; cl = "CL.exe build"


Watcom 1.9 DOS
--------------
Source: http://openwatcom.mirrors.pair.com/open-watcom-c-dos-1.9.exe
Process: Ran C:\watcom\OWSETENV.BAT to drop me in a command-prompt. "wcc minimal.cpp; wcl minimal.obj".  Can't handle filenames other than 8.3 (no error about that, just said "Unable to open"), so for recursive.cpp had to rename to recur.cpp.
Files: *_watcom1.9dos*


Borland C++ Compiler 5.5.1
--------------------------
Release date: 2000-02 5.5 was released, not sure if the version available online has been updated since then.
Source: Signed up at http://forms.embarcadero.com/forms/BCC32CompilerDownload
Process: The compiler kept telling me it didn't know where files were, so I finally just copied my .cpp to C:\Borland\BCC55\Bin and copied everything in C:\Borland\BCC55\lib to there as well.  (Ghetto hacking)
Files: *_borland5.5*


Dev-C++ 5 beta release (4.9.9.2)
--------------------------------
Release date: 2012-10-11
Source: http://www.bloodshed.net/dev/devcpp.html -> SourceForge (http://sourceforge.net/projects/dev-cpp/files/Binaries/Dev-C%2B%2B%204.9.9.2/devcpp-4.9.9.2_setup.exe/download?use_mirror=hivelocity)
Process: Created new console project.  Copied over default code with my own.
Files: *_devcpp5*


Intel Composer XE Evaluation 2013 SP1
-------------------------------------
Release date:
Source: http://software.intel.com/en-us/Intel-composer-xe-evaluation-options/ Filled out form to receive email.
Process: Installation required a Microsoft product installed.  I said no. Wrong answer, can't compile anything.  Installed VS 2008 and ran "C:\Program Files\Intel\Composer XE 2013 SP1\bin\compilears.bat ia32 vs2008" then "cl minimal.cpp"
Files: *_intel_vs2008*


lcc-win32 3.8
-------------
Release date: Compiled March 29 2013 
Source: http://www.cs.virginia.edu/~lcc-win32/
Process: Copied my source to C:\lcc\bin and from there ran: "lcc minimal.cpp; lcclnk minimal.obj"
Files: *_lcc*


MinGW
-----
Source: http://www.mingw.org/
Process: Copied sourse code to C:\mingw\bin and ran "gcc minimal.cpp -o minimal.exe" for gcc, gpp, and c++ which all appear to be gcc 4.8.1 but are unique binaries.
Files: *_mingw_*


Cygwin
-------
Source: http://cygwin.com/install.html
Process: Copied sourse code to C:\mingw\bin and ran "gcc minimal.cpp -o minimal.exe" for gcc, gpp, and c++ which all appear to be gcc 4.8.2, but are unique binaries.
Files: *_cygwin_*


Visual C++ 2008 Express
-----------------------
Release date: 2008
Source: go.microsoft.com/?linkid=7729279‎
Process: Created a win32 console application project.  Overwrote the _tmain() function with my own main().
Files: *_VS2008*


Visual Studio 2005 Pro
----------------------
Source: MSDN
Process: Installed after having already installed Visual C++ 2008, so hopefully that doesn't skew any results.
Files: *_VS2005*


Visual Studio 2003 Pro
----------------------
Source: MSDN
Process: Reverted my VM and installed this on a vanilla XP SP3 install.  Created an empty win32 console application project and added my source file.
Files: *_VS2003*


Visual Studio 2003 Pro SP1
----------------------
Source: MSDN
Process: Installed SP1 for VS2003 on my VM with VS2003 installed on it. Created an empty win32 console application project and added my source file.
Files: *_VS2003*_SP1*


Windows 7
=========
Visual Studio 2010 Express
--------------------------
Source: Online
Process: Created a win32 console application project.  Overwrote the _tmain() function with my own main().
Files: *_VS2010*


Visual Studio 2012 Express
--------------------------
Source: Online
Process: Created a win32 console application project.  Overwrote the _tmain() function with my own main().
Files: *_VS2012*


Visual Studio 2013 Express
--------------------------
Source: Online
Process: Created a win32 console application project.  Overwrote the _tmain() function with my own main().
Files: *_VS2013*


Visual Studio 2003 Pro
----------------------
Source: MSDN
Process: Created an empty win32 console application project and added my source file.
Files: *_VS2003*_Win7*


Visual Studio 2003 Pro SP1
----------------------
Source: MSDN
Process: Installed SP1 for VS2003 on my VM with VS2003 installed on it.  Created an empty win32 console application project and added my source file.
Files: *_VS2003*_SP1*_Win7*